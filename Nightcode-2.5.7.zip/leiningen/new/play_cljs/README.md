## Introduction

A play-cljs game in which ... well, that part is up to you. Do `boot run` to develop and `boot build` to compile a release version.


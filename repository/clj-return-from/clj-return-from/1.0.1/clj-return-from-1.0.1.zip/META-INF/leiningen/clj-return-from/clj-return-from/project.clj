(defproject clj-return-from "1.0.1"
  :description "Emulate common lisps return-from for clojure"
  :java-source-paths ["java"]
  :dependencies [[org.clojure/tools.macro "0.1.1"]]
  )



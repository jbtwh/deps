(defproject environ/environ.lein "0.3.1"
  :description "Leiningen plugin for Environ"
  :url "https://github.com/weavejester/environ"
  :eval-in-leiningen true)

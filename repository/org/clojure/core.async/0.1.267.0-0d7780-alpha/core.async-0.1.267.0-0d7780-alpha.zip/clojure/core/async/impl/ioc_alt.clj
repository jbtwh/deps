(ns ^{:skip-wiki true}
  clojure.core.async.impl.ioc-alt
  (:require [clojure.core.async.impl.ioc-macros :refer :all :as m]
            [clojure.core.async.impl.dispatch :as dispatch]  
            [clojure.core.async.impl.protocols :as impl]))



(ns {{namespace}}
  (:gen-class))

(defn -main []
  (println "Hello, World!"))

window.java = {};
window.java.onload = function(){};
window.java.onautosave = function(){};
window.java.onchange = function(){};
window.java.onenter = function(){};
window.java.oneval = function(){};

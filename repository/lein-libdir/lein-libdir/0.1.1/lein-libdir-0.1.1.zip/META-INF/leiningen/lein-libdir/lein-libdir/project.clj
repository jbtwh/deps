(defproject lein-libdir "0.1.1"
  :description "Copy jar dependencies into the project lib directory"
  :url "http://github.com/djpowell/lein-libdir"
  :license {:name "Eclipse Public License"
            :url "http://www.eclipse.org/legal/epl-v10.html"}
  :eval-in-leiningen true)